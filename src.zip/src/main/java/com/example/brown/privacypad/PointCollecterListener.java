package com.example.brown.privacypad;

import android.graphics.Point;

import java.util.List;

/**
 * Created by Brown on 1/31/17.
 */

public interface PointCollecterListener {

    public void pointscollected(List<Point> ponts);
}
